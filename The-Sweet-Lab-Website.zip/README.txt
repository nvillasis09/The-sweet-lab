# The Sweet Lab Website

This version removes all Cost & Profit, COGS, profit, and profit-margin sections.

## Logo
Put the original logo file named `sweet-lab-logo.jpg` in the same GitHub repository/folder as `index.html`.

## Files
- `index.html` — complete website
- `sweet-lab-logo.jpg` — add your original logo here
