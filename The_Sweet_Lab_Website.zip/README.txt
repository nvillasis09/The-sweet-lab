THE SWEET LAB WEBSITE

1. Open index.html to preview the website.
2. To make it accessible from a phone/QR code, upload the entire folder to a web host that gives you a public website link.
3. Keep index.html and sweet-lab-logo.jpg together.
4. Once you have the final public website link, send it to ChatGPT and a QR code can be made that points directly to it.

Files:
- index.html = website
- sweet-lab-logo.jpg = cropped logo from your project board
